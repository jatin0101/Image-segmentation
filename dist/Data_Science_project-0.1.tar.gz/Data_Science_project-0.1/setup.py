import setuptools

setuptools.setup(
    name='Data_Science_project',
    version='0.1',
    author="Jatin Gupta",
    author_email="jating1120@gmail.com",
    description="Python data science project - Image analysis",
    packages=setuptools.find_packages(),
    url="",
    license="",   
)